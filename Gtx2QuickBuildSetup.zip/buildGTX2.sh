#!/bin/bash

display_help()  #function to display infromation about the script 
{
	echo
	echo
	echo "NAME"
	echo
	echo "       ./buildGTX2.sh - a more easy and time saving Gtx2 Build Execution "
	echo
	echo "SYNOPSIS"
	echo
	echo "       ./buildGTX2.sh [-skipT] [-skipS]"
	echo
	echo "       ./buildGTX2.sh [-skipT]"
	echo
	echo "       ./buildGTX2.sh [-skipS]"
	echo
	echo "       ./buildGTX2.sh [-help]"
	echo
	echo "DESCRIPTION"
	echo
	echo "       This is a script which makes the building process for a developer" 
	echo "       a more easy and time saving process .This takes few optional arguments"
	echo "       to achieve slightly different behavior."
	echo "       By default , if you only run ./buildGTX2.sh it will"
	echo "       (1) stop the server," 
	echo "       (2) do a build of modules that has an update along with its dependencies and execute the test cases "
	echo "       (3) start the server."
	echo "       It will not trigger a build incase of changes in .vm, .js, .css, .html files"
	echo "       It will build when it detects changes locally as well as after a svn update"
	echo "       This command is to be run from c:\dev folder."
	echo
	echo "OPTIONS"
	echo
	echo "       ./buildGTX2.sh may be invoked with the following command-line options:"
	echo
	echo "       -help" 
	echo "       	To display the Manual Page for ./buildGTX2.sh ."
	echo
	echo "       -skipT, -t" 
	echo "       	Optional argument. Used to skip test case compiling and execution."
	echo
	echo "       -skipS, -s"
	echo "       	Optional argument. Used to skip the start of server."
	echo
	echo "AUTHOR"
	echo
	echo "       Written by Miracle T. D'souza and Rahul D'costa"
}

do_gtx2_build()  #function to build gtx2 based on the options specified ( skipServer , skipTest  )
{
	gtx2Path="";
	listToBuild="";
	skipParameter="";
	startServer=true;
	
	if [ -e ~/fastGtx2Build-Config.properties ]
	then
		mapfile -t properties < ~/fastGtx2Build-Config.properties
		gtx2Path=$(printf "${properties[0]}" | cut -d'=' -f2);
	else
		gtx2Path="views/gtx2/core/";
	    echo "[Warning] : Could not find fastGtx2Build-Config.properties file using default Gtx2 Codebase path $gtx2Path"
	fi	
	
	if [ $2 = true ] 
	then
		skipParameter="-Dmaven.test.skip=true" ;
	fi
	
	./apps/tomcat/server/myserver/bin/stop.sh
	cd $gtx2Path
	
	if [ ! -f ~/tempWarTimeStamp ]
	then
		touch ~/tempWarTimeStamp
	fi
	printf "\n\nLooking at Code Changes to Build Modules \n"
	echo "Please Wait....................."
	for folder in `ls -d */`;
	do 
		if [ $folder != "sync/" -a  $folder != "hostclient-integration/" -a  $folder != "hostclient-logging/" -a  $folder != "jacoco-unit/" -a  $folder != "target/"  ]
		then
			if [ `find $folder -not -path '*/\.*' -not -name "*.vm" -not -name "*.css" -not -name "*.js" -not -name "*.html" -type f -newer ~/tempWarTimeStamp | wc -l` -gt 0 ]
			then
				listToBuild=$listToBuild,$folder;
			fi
		fi
	done
	
	if [ "$listToBuild" != "" ]
	then
		printf "\n[Found Changes]...\nBuild Initiated.....................\n"
	    mvn clean -pl $listToBuild -amd;
		
		if mvn install $skipParameter -pl $listToBuild -amd 
		then 
			startServer=true;
			if [ $(printf "${properties[1]}" | cut -d'=' -f2) == "true" ]
			then
				mvn eclipse:eclipse
			fi
			touch ~/tempWarTimeStamp
		else
			startServer=false;
			echo "Build Failed for $listToBuild"; 
		fi
	else
		printf "\n[No Changes Found]...\nBuild Skipped .....................\n"
	fi

	if [ $1 = true ] 
	then
		startServer=false;
	fi
	
	if [ $startServer = true ]
	then
		cd ~/apps/tomcat/server/myserver/bin/
		./start.sh
		echo "Server started";	
	else
	    printf "\nServer Start Skipped .....................\n"
	fi

}


##**********Start of Script **********##
skipServer=false;
skipTest=false;
options=$(echo $@ | sed 's/-skipS/-s/g; s/-skipT/-t/g')

case "$options" in
   "-s") 	skipServer=true;
			do_gtx2_build $skipServer $skipTest
			;;
   "-t")	skipTest=true;
			do_gtx2_build $skipServer $skipTest
			;;
   "-s -t") skipServer=true;
			skipTest=true;
			do_gtx2_build $skipServer $skipTest
			;;
   "-t -s") skipServer=true;
			skipTest=true;
			do_gtx2_build $skipServer $skipTest
			;;
   "-help") display_help 
			;;
   *)
		if [ $# -eq 0 ]
		then
			do_gtx2_build $skipServer $skipTest
		else
			echo "[[Error]]- Wrong Syntax"
			echo "`basename ${0}`:Please refer below and try again" 
			display_help
			exit 1 
		fi   
        ;;
esac